import tensorflow as tf
import pandas as pd
import numpy as np
from tensorflow import keras
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
from keras.models import Sequential
from keras.layers import Dense
import matplotlib.pyplot as plt

df=pd.read_csv('../Datasets/head.csv', encoding='latin-1')

print(len(df))

df = df[(df['flow'] >= 0.005)]

print(len(df))

df = df.drop(['Unnamed: 0'], axis=1)
df = df.drop(['year'], axis=1)
df = df.drop(['iso_o'], axis=1)
df = df.drop(['iso_d'], axis=1)
df = df.drop(['gdp_o'], axis=1)
df = df.drop(['gdp_d'], axis=1)
df = df.drop(['iso2_o'], axis=1)
df = df.drop(['iso2_d'], axis=1)
df = df.drop(['heg_d'], axis=1)
df = df.drop(['heg_o'], axis=1)
df = df.drop(['conflict'], axis=1)
df = df.drop(['indepdate'], axis=1)
df = df.drop(['col_to'], axis=1)
df = df.drop(['col_fr'], axis=1)
df = df.drop(['sever'], axis=1)
df = df.drop(['sib_conflict'], axis=1)
df['GATT'] = np.where((df['gatt_o']==1)&(df['gatt_d']==1),1,0)
df = df.drop(['gatt_o'], axis=1)
df = df.drop(['gatt_d'], axis=1)
df = df.drop(['eu_to_acp'], axis=1)
df = df.drop(['gsp'], axis=1)
df = df.drop(['gsp_rec'], axis=1)
df = df.drop(['validmirror'], axis=1)
df = df.drop(['family'], axis=1)
df['col_always'] = np.where((df['col_hist']==1)&(df['col_cur']==1),1,0)
df = df.drop(['col_cur'], axis=1)


df['ln_distw'] = np.log(df['distw'])
df = df.drop(['distw'], axis=1)
df['ln_gdpcap_o'] = np.log(df['gdpcap_o'])
df = df.drop(['gdpcap_o'], axis=1)
df['ln_gdpcap_d'] = np.log(df['gdpcap_d'])
df = df.drop(['gdpcap_d'], axis=1)
df['ln_flow'] = np.log(df['flow'])
df = df.drop(['flow'], axis=1)
df['ln_pop_o'] = np.log(df['pop_o'])
df = df.drop(['pop_o'], axis=1)
df['ln_pop_d'] = np.log(df['pop_d'])
df = df.drop(['pop_d'], axis=1)

df['ln_flow'] = df['ln_flow'].round(2)

df = df.dropna(axis=0)

columnsTitles = ['ln_flow','contig', 'comlang_off', 'col_hist', 'col_always', 'rta', 'comleg',
       'comcur', 'acp_to_eu', 'GATT', 'ln_distw', 'ln_gdpcap_o', 'ln_gdpcap_d', 
       'ln_pop_o', 'ln_pop_d']

df = df.reindex(columns=columnsTitles)

df.to_csv('/Users/miguelalejandrolozano/Dropbox/Maestria/Materias/Deep Learning/Final Project/Datasets/headClean.csv')











