#All libraries and functions with randomness have their seeds fixed to a value for reproducibility and fine-tuning of hyperparameters
import os
os.environ['PYTHONHASHSEED']=str(0)
seed_value=27
from numpy.random import seed
seed(seed_value)
from tensorflow import set_random_seed
set_random_seed(seed_value)
import random
random.seed(seed_value)
from keras import backend as K
import tensorflow as tf
session_conf = tf.ConfigProto(intra_op_parallelism_threads=4, inter_op_parallelism_threads=4)
sess = tf.Session(graph=tf.get_default_graph(), config=session_conf)
K.set_session(sess)
import pandas as pd
import numpy as np
from tensorflow import keras
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
from keras.models import Sequential
from keras.layers import Dense
from keras.models import load_model
from keras import regularizers
from keras.utils import CustomObjectScope
from keras.initializers import glorot_uniform


#K.set_session(K.tf.Session(config=K.tf.ConfigProto(intra_op_parallelism_threads=4, inter_op_parallelism_threads=4)))

df=pd.read_csv('../Datasets/headCleanShuffled.csv', encoding='latin-1')

#df = df.sample(frac=1) #Shuffle Data

#df.to_csv('roseShuffled.csv', index=False)

df = df.values

X = df[:,1:15] #Don't forget to check how many independent variables

Y = df[:,0]

X_train, X_val_and_test, Y_train, Y_val_and_test = train_test_split(X, Y, test_size=0.30, random_state=seed_value) #Can add shuffle=True, seed = 69 minimizes the difference in average Y value for training and generalization sets

X_val, X_test, Y_val, Y_test = train_test_split(X_val_and_test, Y_val_and_test, test_size=0.5, random_state=seed_value) #Can add shuffle=True

my_init = keras.initializers.glorot_uniform(seed=seed_value)

model = Sequential([
    Dense(19, activation='elu',
    kernel_initializer=my_init,
    bias_initializer=my_init,
    input_shape=(14,)),#Don't forget to adjust based on how many independent variables I Have
    
    Dense(19, activation='elu',
    kernel_initializer=my_init,
    bias_initializer=my_init),
    
    Dense(19, activation='elu',
    kernel_initializer=my_init,
    bias_initializer=my_init),

    Dense(1,activation = 'elu',
    kernel_initializer=my_init,
    bias_initializer=my_init)
])

model.compile(optimizer='adam',
              loss='mse',
              metrics=['mape'])

with CustomObjectScope({'GlorotUniform': glorot_uniform()}):
        model = load_model('headTrained300MinMSE')

hist = model.fit(X_train, Y_train,
    batch_size=32, epochs=2, validation_data=(X_val, Y_val),verbose=2, shuffle=False)

model.evaluate(X_test, Y_test, verbose=1)

model.save('headTrained1000MinMSE') #Save Model for future training

data = {'mse':hist.history['loss'],'val_mse':hist.history['val_loss'],'mape':hist.history['mean_absolute_percentage_error'],'val_mape':hist.history['val_mean_absolute_percentage_error']} #creating variable with loss in one column and val loss in another one

metrics = pd.DataFrame(data) #Creating dataframe for graphing losses

metrics.to_csv('headMetricsMinMSE.csv') #Exporting csv to graph

Y_test_predicted = model.predict(X_test)

data1 = {'predicted':Y_test_predicted[:,0],'observed':Y_test}

plot = pd.DataFrame(data1)

plot.to_csv('headPredictedMinMSE.csv')

