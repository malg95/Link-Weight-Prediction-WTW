#All libraries and functions with randomness have their seeds fixed to a value for reproducibility and fine-tuning of hyperparameters
import os
os.environ['PYTHONHASHSEED']=str(0)
seed_value=4
from numpy.random import seed
seed(seed_value)
from tensorflow import set_random_seed
set_random_seed(seed_value)
import random
random.seed(seed_value)
from keras import backend as K
import tensorflow as tf
session_conf = tf.ConfigProto(intra_op_parallelism_threads=4, inter_op_parallelism_threads=4)
sess = tf.Session(graph=tf.get_default_graph(), config=session_conf)
K.set_session(sess)
import pandas as pd
import numpy as np
from tensorflow import keras
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
from keras.models import Sequential
from keras.layers import Dense
from keras.models import load_model
from keras import regularizers


#K.set_session(K.tf.Session(config=K.tf.ConfigProto(intra_op_parallelism_threads=4, inter_op_parallelism_threads=4)))

df=pd.read_csv('../Datasets/roseShuffled.csv', encoding='latin-1')

#df = df.sample(frac=1) #Shuffle Data

#df.to_csv('roseShuffled.csv', index=False)

df = df.values

X = df[:,1:18] #Don't forget to check how many independent variables

Y = df[:,0]

my_init = keras.initializers.glorot_uniform(seed=seed_value)

model = Sequential([
    Dense(18, activation='elu',
    kernel_initializer=my_init,
    bias_initializer=my_init,
    input_shape=(17,)),#Don't forget to adjust based on how many independent variables I Have
    
    Dense(18, activation='elu',
    kernel_initializer=my_init,
    bias_initializer=my_init),
    
    Dense(18, activation='elu',
    kernel_initializer=my_init,
    bias_initializer=my_init),

    Dense(1,activation = 'elu',
    kernel_initializer=my_init,
    bias_initializer=my_init)
])

model.compile(optimizer='adam',
              loss='mse',
              metrics=['mape'])

#model = load_model('modelname') #Can load saved model here to continue training

hist = model.fit(X, Y,
    batch_size=32, epochs=983, verbose=2, shuffle=False)

model.save('roseTrained1000MinMSENoSplit') #Save Model for future training

data = {'mse':hist.history['loss'],'mape':hist.history['mean_absolute_percentage_error']} #creating variable with loss in one column and val loss in another one

metrics = pd.DataFrame(data) #Creating dataframe for graphing losses

metrics.to_csv('roseMetricsMinMSENoSplit.csv') #Exporting csv to graph

Y_predicted = model.predict(X)

data1 = {'predicted':Y_predicted[:,0],'observed':Y}

plot = pd.DataFrame(data1)

plot.to_csv('rosePredictedMinMSENoSplit.csv')

